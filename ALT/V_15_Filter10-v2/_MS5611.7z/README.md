Arduino-MS5611
===============

MS5611 Barometric Pressure & Temperature Sensor Arduino Library

This library use I2C to communicate, 2 pins are required to interface.

Read more: http://www.jarzebski.pl/arduino/czujniki-i-sensory/czujnik-cisnienia-i-temperatury-ms5611.html

![MS5611](http://www.jarzebski.pl/media/full/publish/2014/05/ms5611-simple.png)

![MS5611](http://www.jarzebski.pl/media/big/publish/2014/05/ms5611-processing.png)

I need your help
----------------

July 31, 2017

In the near future I plan to refactoring the libraries. The main goal is to improve code quality, new features and add support for different versions of Arduino boards like Uno, Mega and Zero.

For this purpose I need to buy modules, Arduino Boards and lot of beer. 

If you want to support the further and long-term development of libraries, please help.

You can do this by transferring any amount to my PayPal account: paypal@jarzebski.pl

Thanks!
